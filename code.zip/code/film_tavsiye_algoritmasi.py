import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# Veri seti (dosya yolunu)
dosya_yolu = 'C:/Users/furka/Desktop/code/imdb_top_1000.csv'
veri_cercevesi = pd.read_csv(dosya_yolu)

# Film listesini gösterme
def film_listesini_goster():
    print("Film Listesi:")
    for indeks, satir in veri_cercevesi.iterrows():
        print(f"{indeks + 1}: {satir['Series_Title']} ({satir['Released_Year']}) - IMDB Puanı: {satir['IMDB_Rating']:.1f}")

# Kullanıcıdan girdi
def kullanici_begendigi_film():
    while True:
        print("\n FURKAN İLBEY 200430023 PC PROGRAMLAMA-III")
        print("\nLütfen aşağıdaki seçeneklerden birini girin:")
        print("1. Bir film numarası (1 ile {} arasında)".format(len(veri_cercevesi)))
        print("2. Bir film adı")
        secim = input("Seçenek: ")

        if secim == '1':
            film_numarasi = input("Beğendiğiniz film numarasını girin (1 ile {} arasında): ".format(len(veri_cercevesi)))
            if film_numarasi.isdigit():
                film_numarasi = int(film_numarasi)
                if 1 <= film_numarasi <= len(veri_cercevesi):
                    return film_numarasi - 1
                else:
                    print("Geçersiz film numarası, lütfen tekrar deneyin.")
            else:
                print("Geçersiz giriş, lütfen bir sayı girin.")

        elif secim == '2':
            film_adi = input("Beğendiğiniz film adını girin: ")
            eslesmeler = veri_cercevesi[veri_cercevesi['Series_Title'].str.contains(film_adi, case=False, na=False)]
            if not eslesmeler.empty:
                return eslesmeler.index[0]
            else:
                print("Film bulunamadı, lütfen tekrar deneyin.")
        else:
            print("Geçersiz seçenek, lütfen 1 veya 2 girin.")

# Benzerlik matrisini hesaplama
def benzerlik_matrisini_hesapla():
    # Overview sütununu kullanarak TF-IDF matrisini oluşturma
    tfidf = TfidfVectorizer(stop_words='english')
    tfidf_matrisi = tfidf.fit_transform(veri_cercevesi['Overview'])

    # Cosine Similarity matrisini hesaplama
    kosinuz_sim = cosine_similarity(tfidf_matrisi, tfidf_matrisi)

    return kosinuz_sim

# Kullanıcının beğendiği filme benzer filmleri bulma ve listeleme
def benzer_filmleri_tavsiye_et(film_indeksi, kosinuz_sim):
    # Benzerlik skorlarını alma
    benzerlik_skorlari = list(enumerate(kosinuz_sim[film_indeksi]))

    # Benzerlik skorlarına göre filmleri sıralama
    benzerlik_skorlari = sorted(benzerlik_skorlari, key=lambda x: x[1], reverse=True)

    # İlk 10 benzer filmi alma (kendisini hariç tutarak)
    benzerlik_skorlari = benzerlik_skorlari[1:11]

    # Benzer filmleri DataFrame'den alma
    film_indeksleri = [i[0] for i in benzerlik_skorlari]
    benzer_filmler = veri_cercevesi.iloc[film_indeksleri]

    # Kullanıcıya tavsiye etme
    print("\nBeğendiğiniz Film: ")
    print(f"{veri_cercevesi.iloc[film_indeksi]['Series_Title']} ({veri_cercevesi.iloc[film_indeksi]['Released_Year']}) - IMDB Puanı: {veri_cercevesi.iloc[film_indeksi]['IMDB_Rating']:.1f}")
    print(f"Özet: {veri_cercevesi.iloc[film_indeksi]['Overview']}")
    print("\nBenzer Filmler:")
    for indeks, satir in benzer_filmler.iterrows():
        print(f"{satir['Series_Title']} ({satir['Released_Year']}) - IMDB Puanı: {satir['IMDB_Rating']:.1f}")
        print(f"Özet: {satir['Overview']}")
        print("-" * 50)

# Ana fonksiyon
def ana_program():
    while True:
        film_listesini_goster()
        begenilen_film_indeksi = kullanici_begendigi_film()
        kosinuz_sim = benzerlik_matrisini_hesapla()
        benzer_filmleri_tavsiye_et(begenilen_film_indeksi, kosinuz_sim)

        # Kullanıcıya çıkış seçeneği sunma
        cikis_secimi = input("\nBaşka bir film önerisi almak ister misiniz? (Evet/Hayır): ").lower()
        if cikis_secimi != 'evet':
            break

    print("Teşekkürler, program sonlandırılıyor.")
   
if __name__ == "__main__":
    ana_program()
